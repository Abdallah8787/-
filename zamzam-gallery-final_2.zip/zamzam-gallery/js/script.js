// Zamzam Gallery - Enhanced JavaScript File
class ZamzamGallery {
    constructor() {
        this.mediaItems = [];
        this.filteredItems = [];
        this.currentFilter = 'all';
        this.currentView = 'masonry';
        this.currentImageIndex = 0;
        this.searchTerm = '';
        this.isLoading = false;
        this.soundEnabled = true;
        this.currentTheme = 'purple';
        this.currentFont = 'Cairo';
        this.currentBackground = 'gradient';
        this.categories = ['عام', 'طبيعة', 'فن', 'تصوير', 'معمارية', 'طعام'];
        this.brands = ['كانون', 'نيكون', 'سوني', 'فوجي', 'أوليمبوس'];
        this.socialLinks = {
            facebook: '#',
            instagram: '#',
            twitter: '#',
            youtube: '#',
            whatsapp: '#'
        };
        this.masonryInstance = null;
        this.rollingInterval = null;
        this.scene3D = null;
        this.camera3D = null;
        this.renderer3D = null;
        this.group3D = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeParticles();
        this.loadSampleData();
        this.hideLoadingScreen();
        this.updateStats();
        this.showWelcomeMessage();
        this.loadSettings();
    }

    setupEventListeners() {
        // Search functionality
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchTerm = e.target.value.toLowerCase();
                this.filterAndDisplayItems();
            });
        }

        // Filter tabs
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                this.playSound('click');
                document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                this.currentFilter = e.target.dataset.filter;
                this.filterAndDisplayItems();
            });
        });

        // View modes
        document.querySelectorAll('.view-mode').forEach(mode => {
            mode.addEventListener('click', (e) => {
                this.playSound('click');
                document.querySelectorAll('.view-mode').forEach(m => m.classList.remove('active'));
                e.target.classList.add('active');
                this.currentView = e.target.dataset.view;
                this.displayItems();
            });
        });

        // Upload functionality
        const uploadBtn = document.getElementById('upload-btn');
        const fileInput = document.getElementById('file-input');
        const uploadArea = document.getElementById('upload-area');

        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => {
                this.playSound('click');
                this.openModal('upload-modal');
            });
        }

        if (uploadArea) {
            uploadArea.addEventListener('click', () => {
                fileInput.click();
            });

            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });

            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });

            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                this.handleFileUpload(e.dataTransfer.files);
            });
        }

        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                this.handleFileUpload(e.target.files);
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            } else if (e.key === 'ArrowLeft') {
                this.showPreviousImage();
            } else if (e.key === 'ArrowRight') {
                this.showNextImage();
            } else if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                this.downloadAllImages();
            }
        });

        // Modal overlay clicks
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.closeModal(overlay.parentElement.id);
                }
            });
        });

        // Image zoom functionality
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('zoomable-image')) {
                e.target.classList.toggle('zoomed');
            }
        });
    }

    initializeParticles() {
        if (typeof particlesJS !== 'undefined') {
            particlesJS('particles-js', {
                particles: {
                    number: {
                        value: 80,
                        density: {
                            enable: true,
                            value_area: 800
                        }
                    },
                    color: {
                        value: ['#8B5CF6', '#10B981', '#7C3AED']
                    },
                    shape: {
                        type: 'circle',
                        stroke: {
                            width: 0,
                            color: '#000000'
                        }
                    },
                    opacity: {
                        value: 0.5,
                        random: false,
                        anim: {
                            enable: false,
                            speed: 1,
                            opacity_min: 0.1,
                            sync: false
                        }
                    },
                    size: {
                        value: 3,
                        random: true,
                        anim: {
                            enable: false,
                            speed: 40,
                            size_min: 0.1,
                            sync: false
                        }
                    },
                    line_linked: {
                        enable: true,
                        distance: 150,
                        color: '#8B5CF6',
                        opacity: 0.4,
                        width: 1
                    },
                    move: {
                        enable: true,
                        speed: 2,
                        direction: 'none',
                        random: false,
                        straight: false,
                        out_mode: 'out',
                        bounce: false,
                        attract: {
                            enable: false,
                            rotateX: 600,
                            rotateY: 1200
                        }
                    }
                },
                interactivity: {
                    detect_on: 'canvas',
                    events: {
                        onhover: {
                            enable: true,
                            mode: 'repulse'
                        },
                        onclick: {
                            enable: true,
                            mode: 'push'
                        },
                        resize: true
                    },
                    modes: {
                        grab: {
                            distance: 400,
                            line_linked: {
                                opacity: 1
                            }
                        },
                        bubble: {
                            distance: 400,
                            size: 40,
                            duration: 2,
                            opacity: 8,
                            speed: 3
                        },
                        repulse: {
                            distance: 200,
                            duration: 0.4
                        },
                        push: {
                            particles_nb: 4
                        },
                        remove: {
                            particles_nb: 2
                        }
                    }
                },
                retina_detect: true
            });
        }
    }

    loadSampleData() {
        // Enhanced sample data with more details
        const sampleItems = [
            {
                id: 1,
                title: 'منظر طبيعي خلاب في الجبال',
                description: 'صورة جميلة لمنظر طبيعي في الجبال مع غروب الشمس الذهبي',
                type: 'image',
                url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop',
                thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=200&fit=crop',
                views: 1250,
                likes: 89,
                rating: 4.5,
                uploadDate: '2024-01-15',
                category: 'طبيعة',
                brand: 'كانون',
                tags: ['طبيعة', 'جبال', 'غروب', 'منظر طبيعي']
            },
            {
                id: 2,
                title: 'فيديو تايم لابس للمدينة',
                description: 'فيديو تايم لابس يظهر حركة المدينة خلال النهار والليل',
                type: 'video',
                url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
                thumbnail: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=300&h=200&fit=crop',
                views: 2100,
                likes: 156,
                rating: 4.8,
                uploadDate: '2024-01-14',
                category: 'تصوير',
                brand: 'سوني',
                tags: ['مدينة', 'تايم لابس', 'حركة', 'ليل']
            },
            {
                id: 3,
                title: 'لوحة فنية معاصرة',
                description: 'لوحة فنية معاصرة بألوان زاهية ومبهجة تعبر عن الحداثة',
                type: 'image',
                url: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&h=600&fit=crop',
                thumbnail: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=300&h=200&fit=crop',
                views: 890,
                likes: 67,
                rating: 4.2,
                uploadDate: '2024-01-13',
                category: 'فن',
                brand: 'نيكون',
                tags: ['فن', 'لوحة', 'ألوان', 'معاصر']
            },
            {
                id: 4,
                title: 'صورة بورتريه احترافية',
                description: 'صورة بورتريه احترافية بإضاءة مثالية وتركيز دقيق',
                type: 'image',
                url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop',
                thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop',
                views: 1580,
                likes: 124,
                rating: 4.7,
                uploadDate: '2024-01-12',
                category: 'تصوير',
                brand: 'كانون',
                tags: ['بورتريه', 'تصوير', 'احترافي', 'إضاءة']
            },
            {
                id: 5,
                title: 'معمارية حديثة مبتكرة',
                description: 'تصوير معماري لمبنى حديث بتصميم مبتكر وخطوط هندسية',
                type: 'image',
                url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop',
                thumbnail: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=300&h=200&fit=crop',
                views: 950,
                likes: 78,
                rating: 4.3,
                uploadDate: '2024-01-11',
                category: 'معمارية',
                brand: 'فوجي',
                tags: ['معمارية', 'مبنى', 'حديث', 'هندسة']
            },
            {
                id: 6,
                title: 'طعام شهي ومقدم بأناقة',
                description: 'تصوير احترافي لطبق طعام شهي ومقدم بطريقة أنيقة وجذابة',
                type: 'image',
                url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=800&h=600&fit=crop',
                thumbnail: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=300&h=200&fit=crop',
                views: 1320,
                likes: 98,
                rating: 4.6,
                uploadDate: '2024-01-10',
                category: 'طعام',
                brand: 'أوليمبوس',
                tags: ['طعام', 'تصوير', 'شهي', 'أناقة']
            }
        ];

        this.mediaItems = sampleItems;
        this.filteredItems = [...this.mediaItems];
        this.displayItems();
    }

    filterAndDisplayItems() {
        this.filteredItems = this.mediaItems.filter(item => {
            const matchesFilter = this.currentFilter === 'all' || 
                                (this.currentFilter === 'images' && item.type === 'image') ||
                                (this.currentFilter === 'videos' && item.type === 'video');
            
            const matchesSearch = this.searchTerm === '' ||
                                item.title.toLowerCase().includes(this.searchTerm) ||
                                item.description.toLowerCase().includes(this.searchTerm) ||
                                item.category.toLowerCase().includes(this.searchTerm) ||
                                item.brand.toLowerCase().includes(this.searchTerm) ||
                                item.tags.some(tag => tag.toLowerCase().includes(this.searchTerm));
            
            return matchesFilter && matchesSearch;
        });

        this.displayItems();
        this.updateResultsCount();
    }

    displayItems() {
        const galleryContainer = document.getElementById('gallery-container');
        const rollingGallery = document.getElementById('rolling-gallery');
        const gallery3D = document.getElementById('gallery-3d');
        const emptyState = document.getElementById('empty-state');

        if (!galleryContainer) return;

        // Hide all containers first
        galleryContainer.classList.add('hidden');
        rollingGallery.classList.add('hidden');
        gallery3D.classList.add('hidden');
        emptyState.classList.add('hidden');

        if (this.filteredItems.length === 0) {
            emptyState.classList.remove('hidden');
            return;
        }

        switch (this.currentView) {
            case 'masonry':
                this.displayMasonryGallery();
                break;
            case 'grid':
                this.displayGridGallery();
                break;
            case 'rolling':
                this.displayRollingGallery();
                break;
            case '3d':
                this.display3DGallery();
                break;
            default:
                this.displayMasonryGallery();
        }
    }

    displayMasonryGallery() {
        const galleryContainer = document.getElementById('gallery-container');
        galleryContainer.classList.remove('hidden');
        galleryContainer.className = 'gallery-container masonry-layout';
        
        galleryContainer.innerHTML = '';

        this.filteredItems.forEach((item, index) => {
            const itemElement = this.createGalleryItem(item, index);
            galleryContainer.appendChild(itemElement);
        });

        // Initialize Masonry after images load
        if (typeof imagesLoaded !== 'undefined' && typeof Masonry !== 'undefined') {
            imagesLoaded(galleryContainer, () => {
                if (this.masonryInstance) {
                    this.masonryInstance.destroy();
                }
                this.masonryInstance = new Masonry(galleryContainer, {
                    itemSelector: '.gallery-item',
                    columnWidth: '.gallery-item',
                    gutter: 32,
                    percentPosition: true
                });
            });
        }
    }

    displayGridGallery() {
        const galleryContainer = document.getElementById('gallery-container');
        galleryContainer.classList.remove('hidden');
        galleryContainer.className = 'gallery-container grid-layout';
        
        galleryContainer.innerHTML = '';

        this.filteredItems.forEach((item, index) => {
            const itemElement = this.createGalleryItem(item, index);
            galleryContainer.appendChild(itemElement);
        });
    }

    displayRollingGallery() {
        const rollingGallery = document.getElementById('rolling-gallery');
        const rollingTrack = rollingGallery.querySelector('.rolling-track');
        
        rollingGallery.classList.remove('hidden');
        rollingTrack.innerHTML = '';

        // Duplicate items for seamless rolling
        const duplicatedItems = [...this.filteredItems, ...this.filteredItems];
        
        duplicatedItems.forEach((item, index) => {
            const rollingItem = document.createElement('div');
            rollingItem.className = 'rolling-item';
            rollingItem.addEventListener('click', () => this.openImageViewer(index % this.filteredItems.length));

            const isVideo = item.type === 'video';
            const mediaElement = isVideo ? 
                `<video src="${item.url}" muted loop></video>` :
                `<img src="${item.thumbnail || item.url}" alt="${item.title}" loading="lazy">`;

            rollingItem.innerHTML = mediaElement;
            rollingTrack.appendChild(rollingItem);
        });

        // Start rolling animation
        this.startRollingAnimation();
    }

    display3DGallery() {
        const gallery3D = document.getElementById('gallery-3d');
        gallery3D.classList.remove('hidden');
        this.init3DGallery();
    }

    createGalleryItem(item, index) {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'gallery-item glass-icon';
        itemDiv.addEventListener('click', () => this.openImageViewer(index));

        const isVideo = item.type === 'video';
        const mediaElement = isVideo ? 
            `<video class="gallery-item-image" src="${item.url}" muted loop></video>` :
            `<img class="gallery-item-image" src="${item.thumbnail || item.url}" alt="${item.title}" loading="lazy">`;

        itemDiv.innerHTML = `
            ${mediaElement}
            <div class="gallery-item-type">${isVideo ? 'فيديو' : 'صورة'}</div>
            <div class="gallery-item-actions">
                <button class="action-btn glass-icon" onclick="event.stopPropagation(); window.zamzamGallery.likeItem(${item.id})">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                </button>
                <button class="action-btn glass-icon" onclick="event.stopPropagation(); window.zamzamGallery.shareItem(${item.id})">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="18" cy="5" r="3"/>
                        <circle cx="6" cy="12" r="3"/>
                        <circle cx="18" cy="19" r="3"/>
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                    </svg>
                </button>
            </div>
            <div class="gallery-item-content">
                <h3 class="gallery-item-title">${item.title}</h3>
                <p class="gallery-item-description">${item.description}</p>
                <div class="gallery-item-meta">
                    <div class="gallery-item-stats">
                        <span class="gallery-item-stat">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                            ${item.views.toLocaleString()}
                        </span>
                        <span class="gallery-item-stat">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                            ${item.likes}
                        </span>
                        <span class="gallery-item-stat">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>
                            </svg>
                            ${item.rating}
                        </span>
                    </div>
                    <span class="gallery-item-date">${item.uploadDate}</span>
                </div>
            </div>
        `;

        return itemDiv;
    }

    openImageViewer(index) {
        this.currentImageIndex = index;
        const item = this.filteredItems[index];
        
        if (!item) return;

        this.playSound('click');

        const imageTitle = document.getElementById('image-title');
        const imageDescription = document.getElementById('image-description');
        const viewerImage = document.getElementById('viewer-image');
        const viewerVideo = document.getElementById('viewer-video');
        const likeCount = document.getElementById('like-count');
        const viewCount = document.getElementById('view-count');
        const uploadDate = document.getElementById('upload-date');

        // Update content
        if (imageTitle) imageTitle.textContent = item.title;
        if (imageDescription) imageDescription.textContent = item.description;
        if (likeCount) likeCount.textContent = item.likes;
        if (viewCount) viewCount.textContent = item.views.toLocaleString();
        if (uploadDate) uploadDate.textContent = item.uploadDate;

        // Show appropriate media element
        if (item.type === 'video') {
            viewerImage.classList.add('hidden');
            viewerVideo.classList.remove('hidden');
            viewerVideo.src = item.url;
        } else {
            viewerVideo.classList.add('hidden');
            viewerImage.classList.remove('hidden');
            viewerImage.src = item.url;
        }

        // Update rating display
        this.updateRatingDisplay(item.rating);

        // Increment view count
        item.views++;
        this.updateStats();

        // Show viewer
        this.openModal('image-viewer');
    }

    startRollingAnimation() {
        if (this.rollingInterval) {
            clearInterval(this.rollingInterval);
        }

        const rollingTrack = document.querySelector('.rolling-track');
        if (!rollingTrack) return;

        let position = 0;
        this.rollingInterval = setInterval(() => {
            position -= 1;
            if (position <= -50) {
                position = 0;
            }
            rollingTrack.style.transform = `translateX(${position}%)`;
        }, 50);
    }

    init3DGallery() {
        if (typeof THREE === 'undefined') return;

        const container = document.getElementById('three-canvas');
        if (!container) return;

        // Clear previous canvas
        while (container.firstChild) {
            container.removeChild(container.firstChild);
        }

        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });

        renderer.setSize(container.clientWidth, container.clientHeight);
        renderer.setClearColor(0x000000, 0);
        container.appendChild(renderer.domElement);

        // Create 3D gallery
        const geometry = new THREE.PlaneGeometry(2, 1.5);
        const group = new THREE.Group();

        this.filteredItems.slice(0, 12).forEach((item, index) => {
            const loader = new THREE.TextureLoader();
            loader.load(item.thumbnail || item.url, (texture) => {
                const material = new THREE.MeshBasicMaterial({ map: texture });
                const plane = new THREE.Mesh(geometry, material);
                
                const angle = (index / 12) * Math.PI * 2;
                const radius = 5;
                plane.position.x = Math.cos(angle) * radius;
                plane.position.z = Math.sin(angle) * radius;
                plane.position.y = (Math.random() - 0.5) * 2;
                plane.lookAt(0, plane.position.y, 0);
                
                group.add(plane);
            });
        });

        scene.add(group);
        camera.position.z = 8;

        // Animation
        const animate = () => {
            requestAnimationFrame(animate);
            group.rotation.y += 0.005;
            renderer.render(scene, camera);
        };
        animate();

        // Store references for controls
        this.scene3D = scene;
        this.camera3D = camera;
        this.renderer3D = renderer;
        this.group3D = group;

        // Handle resize
        const handleResize = () => {
            camera.aspect = container.clientWidth / container.clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(container.clientWidth, container.clientHeight);
        };
        window.addEventListener('resize', handleResize);
    }

    handleFileUpload(files) {
        if (!files || files.length === 0) return;

        this.playSound('upload');

        const uploadProgress = document.getElementById('upload-progress');
        const uploadArea = document.getElementById('upload-area');
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');

        uploadArea.classList.add('hidden');
        uploadProgress.classList.remove('hidden');

        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 15;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                
                // Process files
                Array.from(files).forEach((file, index) => {
                    const title = document.getElementById('upload-title').value || file.name.split('.')[0];
                    const description = document.getElementById('upload-description').value || `تم رفع ${file.type.startsWith('image') ? 'صورة' : 'فيديو'} جديد`;
                    const category = document.getElementById('upload-category').value || 'عام';
                    const tags = document.getElementById('upload-tags').value.split(',').map(tag => tag.trim()).filter(tag => tag);

                    const newItem = {
                        id: Date.now() + index,
                        title: title,
                        description: description,
                        type: file.type.startsWith('image') ? 'image' : 'video',
                        url: URL.createObjectURL(file),
                        thumbnail: URL.createObjectURL(file),
                        views: 0,
                        likes: 0,
                        rating: 0,
                        uploadDate: new Date().toISOString().split('T')[0],
                        category: category,
                        brand: 'غير محدد',
                        tags: tags.length > 0 ? tags : [file.type.startsWith('image') ? 'صورة' : 'فيديو', 'مرفوع']
                    };
                    
                    this.mediaItems.unshift(newItem);
                });

                this.filterAndDisplayItems();
                this.updateStats();
                
                setTimeout(() => {
                    this.closeModal('upload-modal');
                    uploadArea.classList.remove('hidden');
                    uploadProgress.classList.add('hidden');
                    progressFill.style.width = '0%';
                    
                    // Clear form
                    document.getElementById('upload-title').value = '';
                    document.getElementById('upload-description').value = '';
                    document.getElementById('upload-tags').value = '';
                    
                    this.showNotification(`تم رفع ${files.length} ملف بنجاح!`, 'success');
                }, 500);
            }
            
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `جاري الرفع... ${Math.round(progress)}%`;
        }, 100);
    }

    // Settings and Customization Functions
    changeTheme(theme) {
        this.currentTheme = theme;
        document.body.className = document.body.className.replace(/theme-\w+/g, '');
        document.body.classList.add(`theme-${theme}`);
        this.saveSettings();
        this.playSound('click');
        this.showNotification(`تم تغيير اللون إلى ${this.getThemeName(theme)}`, 'success');
    }

    changeFont(font) {
        this.currentFont = font;
        document.body.className = document.body.className.replace(/font-\w+/g, '');
        document.body.classList.add(`font-${font.toLowerCase()}`);
        document.body.style.fontFamily = `var(--font-family)`;
        this.saveSettings();
        this.playSound('click');
        this.showNotification(`تم تغيير الخط إلى ${font}`, 'success');
    }

    changeBackground(background) {
        this.currentBackground = background;
        document.body.className = document.body.className.replace(/bg-\w+/g, '');
        document.body.classList.add(`bg-${background}`);
        this.saveSettings();
        this.playSound('click');
        this.showNotification(`تم تغيير الخلفية إلى ${this.getBackgroundName(background)}`, 'success');
    }

    toggleSound() {
        this.soundEnabled = !this.soundEnabled;
        const soundStatus = document.getElementById('sound-status');
        const soundIcon = document.getElementById('sound-icon');
        
        if (soundStatus) {
            soundStatus.textContent = this.soundEnabled ? 'تشغيل' : 'إيقاف';
        }
        
        if (soundIcon) {
            soundIcon.innerHTML = this.soundEnabled ? 
                '<polygon points="11,5 6,9 2,9 2,15 6,15 11,19"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>' :
                '<polygon points="11,5 6,9 2,9 2,15 6,15 11,19"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>';
        }
        
        this.saveSettings();
        this.showNotification(`تم ${this.soundEnabled ? 'تشغيل' : 'إيقاف'} الأصوات`, 'success');
    }

    toggleSettings() {
        const settingsPanel = document.getElementById('settings-panel');
        settingsPanel.classList.toggle('open');
        this.playSound('click');
    }

    // Category and Brand Management
    openCategoryManager() {
        this.populateCategoryManager();
        this.openModal('category-modal');
        this.playSound('click');
    }

    populateCategoryManager() {
        const categoryList = document.getElementById('category-list');
        const brandList = document.getElementById('brand-list');

        if (categoryList) {
            categoryList.innerHTML = '';
            this.categories.forEach(category => {
                const categoryItem = document.createElement('div');
                categoryItem.className = 'category-item';
                categoryItem.innerHTML = `
                    <span>${category}</span>
                    <button onclick="window.zamzamGallery.removeCategory('${category}')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                    </button>
                `;
                categoryList.appendChild(categoryItem);
            });
        }

        if (brandList) {
            brandList.innerHTML = '';
            this.brands.forEach(brand => {
                const brandItem = document.createElement('div');
                brandItem.className = 'brand-item';
                brandItem.innerHTML = `
                    <span>${brand}</span>
                    <button onclick="window.zamzamGallery.removeBrand('${brand}')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                    </button>
                `;
                brandList.appendChild(brandItem);
            });
        }
    }

    addCategory() {
        const newCategoryInput = document.getElementById('new-category');
        const newCategory = newCategoryInput.value.trim();
        
        if (newCategory && !this.categories.includes(newCategory)) {
            this.categories.push(newCategory);
            this.populateCategoryManager();
            this.updateCategorySelect();
            newCategoryInput.value = '';
            this.playSound('click');
            this.showNotification(`تم إضافة التصنيف: ${newCategory}`, 'success');
        }
    }

    removeCategory(category) {
        const index = this.categories.indexOf(category);
        if (index > -1) {
            this.categories.splice(index, 1);
            this.populateCategoryManager();
            this.updateCategorySelect();
            this.playSound('click');
            this.showNotification(`تم حذف التصنيف: ${category}`, 'success');
        }
    }

    addBrand() {
        const newBrandInput = document.getElementById('new-brand');
        const newBrand = newBrandInput.value.trim();
        
        if (newBrand && !this.brands.includes(newBrand)) {
            this.brands.push(newBrand);
            this.populateCategoryManager();
            newBrandInput.value = '';
            this.playSound('click');
            this.showNotification(`تم إضافة العلامة التجارية: ${newBrand}`, 'success');
        }
    }

    removeBrand(brand) {
        const index = this.brands.indexOf(brand);
        if (index > -1) {
            this.brands.splice(index, 1);
            this.populateCategoryManager();
            this.playSound('click');
            this.showNotification(`تم حذف العلامة التجارية: ${brand}`, 'success');
        }
    }

    updateCategorySelect() {
        const categorySelect = document.getElementById('upload-category');
        if (categorySelect) {
            categorySelect.innerHTML = '';
            this.categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category;
                option.textContent = category;
                categorySelect.appendChild(option);
            });
        }
    }

    // Social Media Management
    editSocialLinks() {
        this.populateSocialEditor();
        this.openModal('social-modal');
        this.playSound('click');
    }

    populateSocialEditor() {
        const socialEditor = document.getElementById('social-editor');
        if (!socialEditor) return;

        socialEditor.innerHTML = '';

        const platforms = {
            facebook: { name: 'فيسبوك', icon: 'M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z' },
            instagram: { name: 'إنستغرام', icon: 'M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.62 5.367 11.987 11.988 11.987 6.62 0 11.987-5.367 11.987-11.987C24.014 5.367 18.637.001 12.017.001z' },
            twitter: { name: 'تويتر', icon: 'M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z' },
            youtube: { name: 'يوتيوب', icon: 'M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814z' },
            whatsapp: { name: 'واتساب', icon: 'M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.488' }
        };

        Object.entries(platforms).forEach(([platform, data]) => {
            const editorItem = document.createElement('div');
            editorItem.className = 'social-editor-item';
            editorItem.innerHTML = `
                <div class="social-icon">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="${data.icon}"/>
                    </svg>
                </div>
                <label>${data.name}:</label>
                <input type="url" value="${this.socialLinks[platform]}" onchange="window.zamzamGallery.updateSocialLink('${platform}', this.value)" placeholder="أدخل رابط ${data.name}">
            `;
            socialEditor.appendChild(editorItem);
        });
    }

    updateSocialLink(platform, url) {
        this.socialLinks[platform] = url;
        this.updateSocialLinksDisplay();
        this.saveSettings();
    }

    updateSocialLinksDisplay() {
        const socialLinks = document.getElementById('social-links');
        if (!socialLinks) return;

        const links = socialLinks.querySelectorAll('.social-link');
        links.forEach(link => {
            const platform = link.dataset.platform;
            if (this.socialLinks[platform]) {
                link.href = this.socialLinks[platform];
                link.style.display = 'flex';
            } else {
                link.style.display = 'none';
            }
        });
    }

    // Utility Functions
    downloadAllImages() {
        this.playSound('click');
        
        if (this.filteredItems.length === 0) {
            this.showNotification('لا توجد صور للتحميل', 'error');
            return;
        }

        this.showNotification('جاري تحضير التحميل...', 'info');

        // Create a zip file (simulated)
        setTimeout(() => {
            this.filteredItems.forEach((item, index) => {
                if (item.type === 'image') {
                    const link = document.createElement('a');
                    link.href = item.url;
                    link.download = `${item.title}_${index + 1}.jpg`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            });
            
            this.showNotification(`تم تحميل ${this.filteredItems.filter(item => item.type === 'image').length} صورة`, 'success');
        }, 1000);
    }

    downloadCurrentImage() {
        const item = this.filteredItems[this.currentImageIndex];
        if (item && item.type === 'image') {
            const link = document.createElement('a');
            link.href = item.url;
            link.download = `${item.title}.jpg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            this.playSound('click');
            this.showNotification('تم تحميل الصورة', 'success');
        }
    }

    editCurrentImage() {
        const item = this.filteredItems[this.currentImageIndex];
        if (item) {
            // Open edit modal (simplified implementation)
            const newTitle = prompt('أدخل العنوان الجديد:', item.title);
            if (newTitle) {
                item.title = newTitle;
                document.getElementById('image-title').textContent = newTitle;
                this.displayItems();
                this.playSound('click');
                this.showNotification('تم تحديث العنوان', 'success');
            }
        }
    }

    likeCurrentImage() {
        const item = this.filteredItems[this.currentImageIndex];
        if (item) {
            item.likes++;
            const likeCount = document.getElementById('like-count');
            if (likeCount) likeCount.textContent = item.likes;
            this.updateStats();
            this.playSound('click');
            this.showNotification('تم إضافة الإعجاب!', 'success');
        }
    }

    shareCurrentImage() {
        const item = this.filteredItems[this.currentImageIndex];
        if (item && navigator.share) {
            navigator.share({
                title: item.title,
                text: item.description,
                url: window.location.href
            }).then(() => {
                this.showNotification('تم مشاركة الصورة بنجاح!', 'success');
            }).catch(() => {
                this.copyToClipboard(window.location.href);
                this.showNotification('تم نسخ الرابط إلى الحافظة!', 'success');
            });
        } else {
            this.copyToClipboard(window.location.href);
            this.showNotification('تم نسخ الرابط إلى الحافظة!', 'success');
        }
    }

    likeItem(id) {
        const item = this.mediaItems.find(item => item.id === id);
        if (item) {
            item.likes++;
            this.displayItems();
            this.updateStats();
            this.playSound('click');
            this.showNotification('تم إضافة الإعجاب!', 'success');
        }
    }

    shareItem(id) {
        const item = this.mediaItems.find(item => item.id === id);
        if (item && navigator.share) {
            navigator.share({
                title: item.title,
                text: item.description,
                url: window.location.href
            }).then(() => {
                this.showNotification('تم مشاركة العنصر بنجاح!', 'success');
            }).catch(() => {
                this.copyToClipboard(window.location.href);
                this.showNotification('تم نسخ الرابط إلى الحافظة!', 'success');
            });
        } else {
            this.copyToClipboard(window.location.href);
            this.showNotification('تم نسخ الرابط إلى الحافظة!', 'success');
        }
    }

    showPreviousImage() {
        if (this.currentImageIndex > 0) {
            this.openImageViewer(this.currentImageIndex - 1);
        }
    }

    showNextImage() {
        if (this.currentImageIndex < this.filteredItems.length - 1) {
            this.openImageViewer(this.currentImageIndex + 1);
        }
    }

    updateRatingDisplay(rating) {
        const stars = document.querySelectorAll('.star');
        stars.forEach((star, index) => {
            if (index < Math.floor(rating)) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
    }

    rateCurrentImage(rating) {
        const item = this.filteredItems[this.currentImageIndex];
        if (item) {
            item.rating = rating;
            this.updateRatingDisplay(rating);
            this.updateStats();
            this.playSound('click');
            this.showNotification('تم تحديث التقييم بنجاح!', 'success');
        }
    }

    clearFilters() {
        this.searchTerm = '';
        this.currentFilter = 'all';
        
        const searchInput = document.getElementById('search-input');
        if (searchInput) searchInput.value = '';
        
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.classList.remove('active');
            if (tab.dataset.filter === 'all') {
                tab.classList.add('active');
            }
        });
        
        this.filterAndDisplayItems();
        this.playSound('click');
        this.showNotification('تم مسح جميع الفلاتر!', 'success');
    }

    updateResultsCount() {
        const resultsCount = document.getElementById('results-count');
        if (resultsCount) {
            resultsCount.textContent = `${this.filteredItems.length} نتيجة`;
        }
    }

    updateStats() {
        const totalItems = document.getElementById('total-items');
        const totalViews = document.getElementById('total-views');
        const totalLikes = document.getElementById('total-likes');
        const averageRating = document.getElementById('average-rating');

        if (totalItems) {
            totalItems.textContent = this.mediaItems.length.toLocaleString();
        }

        if (totalViews) {
            const views = this.mediaItems.reduce((sum, item) => sum + item.views, 0);
            totalViews.textContent = views.toLocaleString();
        }

        if (totalLikes) {
            const likes = this.mediaItems.reduce((sum, item) => sum + item.likes, 0);
            totalLikes.textContent = likes.toLocaleString();
        }

        if (averageRating) {
            const avgRating = this.mediaItems.length > 0 
                ? this.mediaItems.reduce((sum, item) => sum + item.rating, 0) / this.mediaItems.length 
                : 0;
            averageRating.textContent = avgRating.toFixed(1);
        }
    }

    // 3D Gallery Controls
    rotate3DLeft() {
        if (this.group3D) {
            this.group3D.rotation.y -= 0.1;
        }
        this.playSound('click');
    }

    rotate3DRight() {
        if (this.group3D) {
            this.group3D.rotation.y += 0.1;
        }
        this.playSound('click');
    }

    zoom3DIn() {
        if (this.camera3D) {
            this.camera3D.position.z = Math.max(3, this.camera3D.position.z - 0.5);
        }
        this.playSound('click');
    }

    zoom3DOut() {
        if (this.camera3D) {
            this.camera3D.position.z = Math.min(15, this.camera3D.position.z + 0.5);
        }
        this.playSound('click');
    }

    // Rolling Gallery Controls
    rollLeft() {
        // Implement rolling left logic
        this.playSound('click');
    }

    rollRight() {
        // Implement rolling right logic
        this.playSound('click');
    }

    // Modal Management
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
        }
        this.playSound('click');
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
    }

    // Welcome Message
    showWelcomeMessage() {
        setTimeout(() => {
            const welcomeMessage = document.getElementById('welcome-message');
            if (welcomeMessage) {
                welcomeMessage.classList.remove('hidden');
            }
        }, 3000);
    }

    closeWelcomeMessage() {
        const welcomeMessage = document.getElementById('welcome-message');
        if (welcomeMessage) {
            welcomeMessage.classList.add('hidden');
        }
        this.playSound('click');
    }

    // Sound Management
    playSound(type) {
        if (!this.soundEnabled) return;

        const audio = document.getElementById(`${type}-sound`);
        if (audio) {
            audio.currentTime = 0;
            audio.play().catch(() => {
                // Ignore audio play errors
            });
        }
    }

    // Settings Persistence
    saveSettings() {
        const settings = {
            theme: this.currentTheme,
            font: this.currentFont,
            background: this.currentBackground,
            soundEnabled: this.soundEnabled,
            categories: this.categories,
            brands: this.brands,
            socialLinks: this.socialLinks
        };
        
        localStorage.setItem('zamzam-gallery-settings', JSON.stringify(settings));
    }

    loadSettings() {
        const savedSettings = localStorage.getItem('zamzam-gallery-settings');
        if (savedSettings) {
            try {
                const settings = JSON.parse(savedSettings);
                
                if (settings.theme) this.changeTheme(settings.theme);
                if (settings.font) this.changeFont(settings.font);
                if (settings.background) this.changeBackground(settings.background);
                if (settings.soundEnabled !== undefined) {
                    this.soundEnabled = settings.soundEnabled;
                    this.updateSoundDisplay();
                }
                if (settings.categories) this.categories = settings.categories;
                if (settings.brands) this.brands = settings.brands;
                if (settings.socialLinks) {
                    this.socialLinks = { ...this.socialLinks, ...settings.socialLinks };
                    this.updateSocialLinksDisplay();
                }
                
                this.updateCategorySelect();
            } catch (error) {
                console.error('Error loading settings:', error);
            }
        }
    }

    updateSoundDisplay() {
        const soundStatus = document.getElementById('sound-status');
        const soundIcon = document.getElementById('sound-icon');
        
        if (soundStatus) {
            soundStatus.textContent = this.soundEnabled ? 'تشغيل' : 'إيقاف';
        }
        
        if (soundIcon) {
            soundIcon.innerHTML = this.soundEnabled ? 
                '<polygon points="11,5 6,9 2,9 2,15 6,15 11,19"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>' :
                '<polygon points="11,5 6,9 2,9 2,15 6,15 11,19"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>';
        }
    }

    // Helper Functions
    getThemeName(theme) {
        const themeNames = {
            purple: 'البنفسجي',
            blue: 'الأزرق',
            green: 'الأخضر',
            red: 'الأحمر',
            orange: 'البرتقالي'
        };
        return themeNames[theme] || theme;
    }

    getBackgroundName(background) {
        const backgroundNames = {
            gradient: 'المتدرج',
            dark: 'الداكن',
            blue: 'الأزرق',
            purple: 'البنفسجي'
        };
        return backgroundNames[background] || background;
    }

    copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
        }
    }

    showNotification(message, type = 'info') {
        const container = document.getElementById('notifications');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        container.appendChild(notification);

        this.playSound('notification');

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 5000);
    }

    hideLoadingScreen() {
        setTimeout(() => {
            const loadingScreen = document.getElementById('loading-screen');
            if (loadingScreen) {
                loadingScreen.classList.add('hidden');
            }
        }, 2000);
    }
}

// Global Functions for HTML onclick events
function closeWelcomeMessage() {
    window.zamzamGallery.closeWelcomeMessage();
}

function toggleSettings() {
    window.zamzamGallery.toggleSettings();
}

function changeTheme(theme) {
    window.zamzamGallery.changeTheme(theme);
}

function changeFont(font) {
    window.zamzamGallery.changeFont(font);
}

function changeBackground(background) {
    window.zamzamGallery.changeBackground(background);
}

function toggleSound() {
    window.zamzamGallery.toggleSound();
}

function openCategoryManager() {
    window.zamzamGallery.openCategoryManager();
}

function addCategory() {
    window.zamzamGallery.addCategory();
}

function addBrand() {
    window.zamzamGallery.addBrand();
}

function editSocialLinks() {
    window.zamzamGallery.editSocialLinks();
}

function downloadAllImages() {
    window.zamzamGallery.downloadAllImages();
}

function closeModal(modalId) {
    window.zamzamGallery.closeModal(modalId);
}

function showPreviousImage() {
    window.zamzamGallery.showPreviousImage();
}

function showNextImage() {
    window.zamzamGallery.showNextImage();
}

function likeCurrentImage() {
    window.zamzamGallery.likeCurrentImage();
}

function shareCurrentImage() {
    window.zamzamGallery.shareCurrentImage();
}

function downloadCurrentImage() {
    window.zamzamGallery.downloadCurrentImage();
}

function editCurrentImage() {
    window.zamzamGallery.editCurrentImage();
}

function rateCurrentImage(rating) {
    window.zamzamGallery.rateCurrentImage(rating);
}

function clearFilters() {
    window.zamzamGallery.clearFilters();
}

function rotate3DLeft() {
    window.zamzamGallery.rotate3DLeft();
}

function rotate3DRight() {
    window.zamzamGallery.rotate3DRight();
}

function zoom3DIn() {
    window.zamzamGallery.zoom3DIn();
}

function zoom3DOut() {
    window.zamzamGallery.zoom3DOut();
}

function rollLeft() {
    window.zamzamGallery.rollLeft();
}

function rollRight() {
    window.zamzamGallery.rollRight();
}

// Initialize the gallery when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.zamzamGallery = new ZamzamGallery();
});

// GSAP Animations
if (typeof gsap !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);

    // Animate gallery items on scroll
    gsap.utils.toArray('.gallery-item').forEach((item, index) => {
        gsap.fromTo(item, 
            {
                opacity: 0,
                y: 50,
                scale: 0.8
            },
            {
                opacity: 1,
                y: 0,
                scale: 1,
                duration: 0.6,
                delay: index * 0.1,
                ease: "power2.out",
                scrollTrigger: {
                    trigger: item,
                    start: "top 80%",
                    end: "bottom 20%",
                    toggleActions: "play none none reverse"
                }
            }
        );
    });

    // Animate stats on scroll
    gsap.utils.toArray('.stat-card').forEach((card, index) => {
        gsap.fromTo(card,
            {
                opacity: 0,
                y: 30
            },
            {
                opacity: 1,
                y: 0,
                duration: 0.8,
                delay: index * 0.2,
                ease: "power2.out",
                scrollTrigger: {
                    trigger: card,
                    start: "top 85%",
                    toggleActions: "play none none reverse"
                }
            }
        );
    });

    // Animate header elements
    gsap.timeline()
        .fromTo('.logo-circle-main', 
            { scale: 0, rotation: -180 },
            { scale: 1, rotation: 0, duration: 1, ease: "back.out(1.7)" }
        )
        .fromTo('.main-title',
            { opacity: 0, y: -30 },
            { opacity: 1, y: 0, duration: 0.8, ease: "power2.out" },
            "-=0.5"
        )
        .fromTo('.sub-title',
            { opacity: 0, x: 30 },
            { opacity: 1, x: 0, duration: 0.8, ease: "power2.out" },
            "-=0.6"
        )
        .fromTo('.description',
            { opacity: 0, y: 20 },
            { opacity: 1, y: 0, duration: 0.8, ease: "power2.out" },
            "-=0.4"
        );
}

